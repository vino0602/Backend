package com.WscMap;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class WscMapApplicationTests {

	@Test
	void contextLoads() {
	}

}
