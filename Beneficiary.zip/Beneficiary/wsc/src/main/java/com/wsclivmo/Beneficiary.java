package com.wsclivmo;
import org.springframework.data.annotation.Id;
import org.springframework.data.mongodb.core.mapping.Document;
//import jakarta.persistence.GeneratedValue;
//import jakarta.persistence.GenerationType;
	@Document(collection = "Beneficiary")
	public class Beneficiary {
	@Id
    private String id;
    private String firstname;
    private String lastname;
    private String email;
    private String mobilenumber;
    private String gender;
    private String dob;
    private String addressline1;
    private String addressline2;
    private String insurancename;
    private String medicalhistory;
    private String country;
    private String state;
    private String city;
    private String zip;
    // Constructors
    public Beneficiary() {}

    public Beneficiary(String id,
    		String firstname,
    		String lastname,
    		String email,
    		String mobilenumber,
    		String gender,
    		String dob,
    		String addressline1,
    		String addressline2,
    		String insurancename,
    		String medicalhistory,
    		String country,
    		String state,
    		String city,
    		String zip) 
    {
        	this.id = id;
        	this.firstname = firstname;
        	this.lastname = lastname;
        	this.email = email;
        	this.mobilenumber =mobilenumber;
        	this.gender = gender;
        	this.dob =dob;
        	this.addressline1 = addressline1;
        	this.addressline2 = addressline2;
        	this.insurancename = insurancename;
        	this.medicalhistory = medicalhistory;
        	this.country = country;
        	this.state = state;
        	this.city = city;
        	this.zip = zip;
    }
    // Getters and Setters
    public String getId() {return id;}
    public void setId(String id) {this.id = id;}
    
    public String getFirstName() {return firstname;}
    public void setFirstName(String firstname) {this.firstname = firstname;}
    
    public String getLastName() { return lastname;} 
    public void setLastName (String lastname) { this.lastname = lastname;}
    
    public String getEmail() { return email;} 
    public void setEmail (String email) { this.email = email;}
    
    public String getMobileNumber() { return mobilenumber;} 
    public void setMobileNumber (String mobilenumber) { this.mobilenumber = mobilenumber;}
    
    public String getGender() { return gender;} 
    public void setGender (String gender) { this.gender = gender;}
    
    public String getDOB() { return dob;} 
    public void setDOB (String dob) { this.dob = dob;}
    
    public String getAddressLine1() { return addressline1;} 
    public void setAddressLine1 (String addressline1) { this.addressline1 = addressline1;}
    
    public String getAddressLine2() { return addressline2;} 
    public void setAddressLine2 (String addressline2) { this.addressline2 = addressline2;}
    
    public String getInsuranceName() { return insurancename;} 
    public void setInsuranceName (String insurancename) { this.insurancename = insurancename;}
    
    public String getMedicalHistory() {return medicalhistory;}
    public void setMedicalHistory(String medicalhistory) {this.medicalhistory = medicalhistory;}
    
    public String getCountry() { return country;} 
    public void setCountry (String country) { this.country = country;}
    
    public String getState() { return state;} 
    public void setState (String state) { this.state = state;}
    
    public String getCity() { return city;} 
    public void setCity (String city) { this.city = city;}
    
    public String getZip() { return zip;} 
    public void setZip (String zip) { this.zip = zip;}	
	}