package com.wsclivmo;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import java.util.ArrayList;
import java.util.List;
import java.util.Optional;
import java.util.UUID;

@Service
public class BeneficiaryService {
    @Autowired
    BeneficiaryRepository beneficiaryRepository;
    private List<Beneficiary> beneficiaries = new ArrayList<>();

    // Create or update a beneficiary
    public Beneficiary createOrUpdateBeneficiary(Beneficiary beneficiary) {
        // Check if the email or mobilenumber already exists
        Optional<Beneficiary> existingByEmail = beneficiaryRepository.findByEmail(beneficiary.getEmail());
        Optional<Beneficiary> existingByMobile = beneficiaryRepository.findByMobilenumber(beneficiary.getMobileNumber());

        if (existingByEmail.isPresent() || existingByMobile.isPresent()) {
            // Update the existing beneficiary if found by email or mobile number
            Beneficiary existingBeneficiary = existingByEmail.orElse(existingByMobile.get());
            updateBeneficiaryDetails(existingBeneficiary, beneficiary);
            return beneficiaryRepository.save(existingBeneficiary);
        } else {
            // Create a new beneficiary if no duplicate found
            beneficiary.setId(UUID.randomUUID().toString());
            beneficiaryRepository.save(beneficiary);
            beneficiaries.add(beneficiary);
            return beneficiary;
        }
    }

    // Helper method to update beneficiary details
    private void updateBeneficiaryDetails(Beneficiary existing, Beneficiary updates) {
        existing.setFirstName(updates.getFirstName());
        existing.setLastName(updates.getLastName());
        existing.setEmail(updates.getEmail());
        existing.setMobileNumber(updates.getMobileNumber());
        existing.setGender(updates.getGender());
        existing.setDOB(updates.getDOB());
        existing.setAddressLine1(updates.getAddressLine1());
        existing.setAddressLine2(updates.getAddressLine2());
        existing.setInsuranceName(updates.getInsuranceName());
        existing.setMedicalHistory(updates.getMedicalHistory());
        existing.setCountry(updates.getCountry());
        existing.setState(updates.getState());
        existing.setCity(updates.getCity());
        existing.setZip(updates.getZip());
    }

    // Retrieve all beneficiaries
    public List<Beneficiary> getAllBeneficiaries() {
        return beneficiaries;
    }

    // Retrieve a beneficiary by ID
    public Beneficiary getBeneficiaryById(String id) {
        return beneficiaries.stream()
                .filter(b -> b.getId().equals(id))
                .findFirst()
                .orElse(null);
    }

    // Delete a beneficiary by ID
    public void deleteBeneficiary(String id) {
        beneficiaries.removeIf(b -> b.getId().equals(id));
    }
}
