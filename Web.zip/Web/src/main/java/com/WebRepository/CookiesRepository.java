package com.WebRepository;

import com.WebModel.Cookies;
import org.springframework.data.mongodb.repository.MongoRepository;

public interface CookiesRepository extends MongoRepository<Cookies, String> {
    // You can add custom query methods if needed
}
