package com.WebRepository;

import com.WebModel.LoginRequest;
import org.springframework.data.mongodb.repository.MongoRepository;

public interface LoginRepository extends MongoRepository<LoginRequest, String> {
   
}
