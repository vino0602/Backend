package com.WebRepository;

import com.WebModel.Reviews;
import org.springframework.data.mongodb.repository.MongoRepository;

public interface ReviewsRepository extends MongoRepository<Reviews, String> {
    // You can add custom query methods if needed
}
