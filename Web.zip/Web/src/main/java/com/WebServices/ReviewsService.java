package com.WebServices;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import com.WebModel.Reviews;
import com.WebRepository.ReviewsRepository;

import java.util.List;

@Service
public class ReviewsService {

    @Autowired
    private ReviewsRepository reviewsRepository;

    // Save a new review
    public Reviews addReview(Reviews review) {
        return reviewsRepository.save(review);
    }

    // Get all reviews
    public List<Reviews> getAllReviews() {
        return reviewsRepository.findAll();
    }
}
