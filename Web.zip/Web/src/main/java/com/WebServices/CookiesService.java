package com.WebServices;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import com.WebModel.Cookies;
import com.WebRepository.CookiesRepository;

import java.util.List;

@Service
public class CookiesService {

    @Autowired
    private CookiesRepository cookiesRepository;

    // Save or update the cookie (upsert functionality)
    public Cookies saveCookie(Cookies cookie) {
        // Validate the cookie object for required fields
        if (cookie.getCookieName() == null || cookie.getCookieValue() == null) {
            throw new IllegalArgumentException("Cookie name and value cannot be null");
        }

        return cookiesRepository.save(cookie); // This will perform an upsert (insert or update)
    }

    // Get all cookies
    public List<Cookies> getAllCookies() {
        return cookiesRepository.findAll();
    }

    // Find a cookie by its name
    public Cookies getCookieByName(String cookieName) {
        return cookiesRepository.findById(cookieName).orElse(null); // Assuming `cookieName` is the primary key
    }

    // Delete a cookie by its name
    public void deleteCookieByName(String cookieName) {
        cookiesRepository.deleteById(cookieName); // Deletes a cookie by its name
    }
}
