package com.WebServices;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import com.WebModel.LoginRequest;
import com.WebRepository.LoginRepository;

@Service
public class LoginService {

    @Autowired
    private LoginRepository loginRepository;

    // This method authenticates and upserts the user into MongoDB
    public String authenticate(LoginRequest loginRequest) {
        // Authentication logic
        if ("user@example.com".equals(loginRequest.getEmail()) && "password".equals(loginRequest.getPassword())) {
            // Use upsert to either save or update user based on email
            loginRepository.save(loginRequest); // This can also be used for upsert
            return "Login successful and user data saved!";
        }
        return "Invalid credentials!";
    }

    public String getLoginStatus() {
        return "User is not logged in.";
    }
}
