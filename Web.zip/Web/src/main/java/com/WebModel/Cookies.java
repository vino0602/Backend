package com.WebModel;

import lombok.Data;
import org.springframework.data.mongodb.core.mapping.Document;

@Data // Lombok annotation to generate getters, setters, toString, equals, and hashCode methods
@Document(collection = "cookies") // MongoDB collection name
public class Cookies {

    private String cookieName;        // Name of the cookie
    private String cookieValue;       // Value of the cookie
    private String domain;            // Domain where the cookie is valid
    private String path;              // Path where the cookie is valid
    private String expires;           // Expiration date (e.g., Wed, 20 Dec 2024 12:00:00 GMT)
    private Integer maxAge;           // Maximum age in seconds
    private Boolean httpOnly;         // Prevents access to cookies via client-side JavaScript
    private Boolean secure;           // Ensures cookies are sent over HTTPS only
    private String sameSite;          // SameSite policy: Strict, Lax, or None

    // Default constructor
    public Cookies() {}

    // Parameterized constructor
    public Cookies(String cookieName, String cookieValue, String domain, String path, String expires, Integer maxAge, Boolean httpOnly, Boolean secure, String sameSite) {
        this.cookieName = cookieName;
        this.cookieValue = cookieValue;
        this.domain = domain;
        this.path = path;
        this.expires = expires;
        this.maxAge = maxAge;
        this.httpOnly = httpOnly;
        this.secure = secure;
        this.sameSite = sameSite;
    }

	public String getCookieName() {
		return cookieName;
	}

	public void setCookieName(String cookieName) {
		this.cookieName = cookieName;
	}

	public String getCookieValue() {
		return cookieValue;
	}

	public void setCookieValue(String cookieValue) {
		this.cookieValue = cookieValue;
	}

	public String getDomain() {
		return domain;
	}

	public void setDomain(String domain) {
		this.domain = domain;
	}

	public String getPath() {
		return path;
	}

	public void setPath(String path) {
		this.path = path;
	}

	public String getExpires() {
		return expires;
	}

	public void setExpires(String expires) {
		this.expires = expires;
	}

	public Integer getMaxAge() {
		return maxAge;
	}

	public void setMaxAge(Integer maxAge) {
		this.maxAge = maxAge;
	}

	public Boolean getHttpOnly() {
		return httpOnly;
	}

	public void setHttpOnly(Boolean httpOnly) {
		this.httpOnly = httpOnly;
	}

	public Boolean getSecure() {
		return secure;
	}

	public void setSecure(Boolean secure) {
		this.secure = secure;
	}

	public String getSameSite() {
		return sameSite;
	}

	public void setSameSite(String sameSite) {
		this.sameSite = sameSite;
	}   
    
}
