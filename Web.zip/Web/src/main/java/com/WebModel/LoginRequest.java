package com.WebModel;

//import org.springframework.data.annotation.Id;
import org.springframework.data.mongodb.core.mapping.Document;
import lombok.Data;
import lombok.AllArgsConstructor;
import lombok.NoArgsConstructor;

@Data 
@AllArgsConstructor
@NoArgsConstructor 
@Document(collection = "users") 
public class LoginRequest {
    
    //private String id;
    private String name;
    private String email;
    private String location;
    private String message;
    private String mobileNumber;
    private String exploringFor;
    private String howDidYouHear;
    private String createdAt;
    private String password; 
    
    
	public LoginRequest( String name, String email, String location, String message, String mobileNumber,
			String exploringFor, String howDidYouHear, String createdAt, String password) {
		super();
		//		this.name = name;
		this.email = email;
		this.location = location;
		this.message = message;
		this.mobileNumber = mobileNumber;
		this.exploringFor = exploringFor;
		this.howDidYouHear = howDidYouHear;
		this.createdAt = createdAt;
		this.password = password;
	}



	public String getName() {
		return name;
	}

	public void setName(String name) {
		this.name = name;
	}

	public String getEmail() {
		return email;
	}

	public void setEmail(String email) {
		this.email = email;
	}

	public String getLocation() {
		return location;
	}

	public void setLocation(String location) {
		this.location = location;
	}

	public String getMessage() {
		return message;
	}

	public void setMessage(String message) {
		this.message = message;
	}

	public String getMobileNumber() {
		return mobileNumber;
	}

	public void setMobileNumber(String mobileNumber) {
		this.mobileNumber = mobileNumber;
	}

	public String getExploringFor() {
		return exploringFor;
	}

	public void setExploringFor(String exploringFor) {
		this.exploringFor = exploringFor;
	}

	public String getHowDidYouHear() {
		return howDidYouHear;
	}

	public void setHowDidYouHear(String howDidYouHear) {
		this.howDidYouHear = howDidYouHear;
	}

	public String getCreatedAt() {
		return createdAt;
	}

	public void setCreatedAt(String createdAt) {
		this.createdAt = createdAt;
	}

	public String getPassword() {
		return password;
	}

	public void setPassword(String password) {
		this.password = password;
	}
    
	
	
    
}
