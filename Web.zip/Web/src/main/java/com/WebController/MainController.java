package com.WebController;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.WebModel.Cookies;
import com.WebModel.LoginRequest;
import com.WebModel.Reviews;
import com.WebServices.CookiesService;
import com.WebServices.LoginService;
import com.WebServices.ReviewsService;

@RestController
@RequestMapping("/api")
public class MainController {

    @Autowired
    private CookiesService cookiesService;

    @Autowired
    private ReviewsService reviewsService;

    @Autowired
    private LoginService loginService;

    // Cookies Endpoints

    /**
     * Get all cookies stored in the database.
     */
    @GetMapping("/cookies")
    public List<Cookies> getAllCookies() {
        return cookiesService.getAllCookies();
    }

    /**
     * Save or update a cookie with enhanced fields.
     */
    @PostMapping("/cookies")
    public Cookies saveCookie(@RequestBody Cookies cookie) {
        return cookiesService.saveCookie(cookie);
    }

    /**
     * Get a specific cookie by its name.
     */
    @GetMapping("/cookies/{cookieName}")
    public Cookies getCookieByName(@PathVariable String cookieName) {
        Cookies cookie = cookiesService.getCookieByName(cookieName);
        if (cookie == null) {
            throw new IllegalArgumentException("Cookie with name '" + cookieName + "' not found.");
        }
        return cookie;
    }

    /**
     * Delete a specific cookie by its name.
     */
    @DeleteMapping("/cookies/{cookieName}")
    public String deleteCookieByName(@PathVariable String cookieName) {
        cookiesService.deleteCookieByName(cookieName);
        return "Cookie with name '" + cookieName + "' deleted successfully.";
    }

    // Reviews Endpoints

    @GetMapping("/reviews")
    public List<Reviews> getAllReviews() {
        return reviewsService.getAllReviews();
    }

    @PostMapping("/reviews")
    public Reviews addReview(@RequestBody Reviews review) {
        return reviewsService.addReview(review);
    }

    // Login Endpoints

    @PostMapping("/login")
    public String login(@RequestBody LoginRequest loginRequest) {
        return loginService.authenticate(loginRequest);
    }

    @GetMapping("/login")
    public String getLoginStatus() {
        return loginService.getLoginStatus();
    }
}
